//1) Criar um programa onde o usuário digite o ano de nascimento e retorne a geração a qual ele pertence:

//Sem Geração (até 1945)
//Baby Boomers (nascidos entre 1946 e 1964)
//Geração X (1965-1980)
//Geração Y ou Millennials (1981-1996)
//Geração Z (1997-2010)
//Geração Alfa (a partir de 2011)

//DECLARAÇÃO VARIAVEIS + ENTRADA DE DADOS
var idade = Number(prompt('Digite o seu ano de nascimento: '))

//CONDICIONAIS
 
switch(true){
    case idade <= 1945 :
        alert('Sem geração')
        break 

    case idade >= 1946 && idade <= 1964 :
        alert('Baby Boomers')
        break 

    case idade >= 1965 && idade <= 1980 :
        alert('Geração X')
        break 

    case idade >= 1981 && idade <= 1996 :
        alert('Geração Millenials')
        break 

    case idade >= 1997 && idade <= 2010 :
        alert('Geração z')
        break 

    case idade >= 2011 :
        alert('Geração alfa')
        break 

    default :
        alert('Digite corretamente')
}