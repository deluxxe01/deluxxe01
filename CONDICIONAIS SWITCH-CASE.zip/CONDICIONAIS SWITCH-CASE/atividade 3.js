 //3) Em um determinado e-commerce, o frete para produtos possui o valor fixo de R$12,50.
 //A loja possui benefícios para assinantes em três categorias: 
 //1) Assinante Premium, ganha 20% de desconto e frete grátis 
 //2) Assinante Gold, ganha 20% de desconto mas paga frete 
 //3) Assinante Silver, ganha 10% de desconto mas paga frete. 
 //4) Não assinante, sem benefícios. 
 //Faça um programa que solicite o valor da compra e a categoria de assinante (1, 2, 3 ou 4).
 //Mostrar na tela o valor da compra de acordo com a opção escolhida.

//DECLARAÇÃO VARIAVEIS + ENTRADA DE DADOS + CALCULOS
var compra = Number(prompt('Digite o valor da compra: '))
var categoria = Number(prompt('Digite a categoria de assinante (1, 2, 3, ou 4): '))
var valorCompraFixo = compra + 12.50

//CONDICIONAIS
switch(categoria){
    case 1 :
        var valorDesconto = valorCompraFixo * 0.2 - 12.50
        var valorCompra = valorCompraFixo - valorDesconto
        alert('Valor da compra em assinante premium: '+ valorCompra)
        break

    case 2 :
        var valorDesconto = valorCompraFixo * 0.2
        var valorCompra = valorCompraFixo - valorDesconto
        alert('Valor da compra em assinante gold: '+ valorCompra)
        break

    case 3 :
        var valorDesconto = valorCompraFixo * 0.1
        var valorCompra = valorCompraFixo - valorDesconto
        alert('Valor da compra em assinante silver: '+ valorCompra)
        break 

    case 4 :
        alert('Valor da compra sem beneficios: '+ valorCompraFixo)

}