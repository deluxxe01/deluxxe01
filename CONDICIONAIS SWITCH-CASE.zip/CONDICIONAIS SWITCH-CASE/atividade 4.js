//4) Numa competição de arremesso de peteca, 
//o competidor tem direito a 3 arremessos para que a peteca caia em um alvo 
//com áreas e pontuações de 0 a 5, sendo 5 no centro e 0 fora do alvo.
// Faça um programa que pergunte a pontuação de cada arremesso e ao final mostre o resultado(soma dos pontos) e 
//a classifição: 15 pontos (deus da peteca), de 14 a 10 (petequeiro profissa),
// de 9 a 5 (petequeiro de final de semana), de 4 a 1 (pseudo-petequeiro) e 0 pontos (nunca petequeiro).

var arremessoUm = Number(prompt('Digite o ponto do primeiro arremesso: '))
var arremessoDois = Number(prompt('Digite o ponto do segundo arremesso: '))
var arremessoTres = Number(prompt('Digite o ponto do terceiro arremesso: '))

//CALCULOS
let somaArremessos = arremessoUm + arremessoDois + arremessoTres

//CONDICIONAIS
switch(true){
    case somaArremessos === 15 :
         alert('Pontos: '+ somaArremessos + ' Deus da peteca!')
         break 
        
    case somaArremessos >= 10 && somaArremessos <= 14 :
         alert('Pontos: '+ somaArremessos + ' Petequeiro profissa!')
         break

    case somaArremessos >= 5 && somaArremessos <= 9 :
        alert('Pontos: '+ somaArremessos + ' Petequeiro de final de semana!')
        break

    case somaArremessos >= 1 && somaArremessos <= 4 :
        alert('Pontos: '+ somaArremessos + ' Pseudo-petequeiro!')
        break 

    case somaArremessos === 0 :
        alert('Pontos: '+ somaArremessos + ' Nunca petequeiro!')

    default:
        alert('Algum ponto digitado errado!')


}