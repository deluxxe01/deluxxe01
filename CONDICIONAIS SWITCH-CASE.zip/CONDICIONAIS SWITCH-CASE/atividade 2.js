//2) Desenvolva um programa que pergunte ao usuário o número da sua conta bancária e o tipo de operação a ser realizada:
//1) Saldo 2) Depósito 3) Saque. Nas opções de depósito e saque, perguntar o valor a ser depositado ou sacado e mostrar o saldo atualizado na tela.
//Na opção saldo, apenas mostrar o saldo atual na tela. Considere que um saque só pode ser realizado caso haja saldo suficiente. 
//Criar uma variável com um valor que represente o saldo inicial.


var numeroConta = Number(prompt('Digite o número da sua conta bancária: '))
var operacao = Number(prompt('Digite a opção que queira escolher:' + '\n1) SALDO' + '\n2) DEPÓSITO' + '\n3) SAQUE'))
var saldoInicial = 200000000000000

switch(operacao){
    case 1 :
        alert('Valor do saldo inicial: ' + saldoInicial)
        break 

    case 2 :
        var depositado = Number(prompt('Digite o valor a ser depositado: '))
        var conta = saldoInicial + depositado 
        alert('Valor depositado: '+ depositado + '\nValor total com o deposito: '+ conta)
        break 

    case 3 :
        var saque = Number(prompt('Digite o valor a ser sacado: '))
        var conta = saldoInicial - saque
        alert('Valor sacado: '+ saque + '\nValor total do saldo com saque: '+ conta)
        break 
        
}

